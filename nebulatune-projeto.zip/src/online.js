let cbSeq = 0

function jsonp(url, timeout = 10000) {
  return new Promise((resolve, reject) => {
    cbSeq += 1
    const id = `__nt_online_${cbSeq}_${Date.now()}`
    const script = document.createElement('script')
    let done = false
    const clean = () => {
      delete window[id]
      if (script.parentNode) script.parentNode.removeChild(script)
    }
    const timer = setTimeout(() => {
      if (done) return
      done = true
      clean()
      reject(new Error('timeout'))
    }, timeout)
    window[id] = (data) => {
      if (done) return
      done = true
      clearTimeout(timer)
      clean()
      resolve(data)
    }
    script.onerror = () => {
      if (done) return
      done = true
      clearTimeout(timer)
      clean()
      reject(new Error('network'))
    }
    const sep = url.includes('?') ? '&' : '?'
    script.src = `${url}${sep}output=jsonp&callback=${id}`
    document.head.appendChild(script)
  })
}

function conceptTrack(item) {
  return {
    id: `dz-${item.id}`,
    title: item.title || 'Desconhecida',
    artist: item.artist?.name || 'Desconhecido',
    album: item.album?.title || '',
    coverUrl: item.album?.cover_medium || item.artist?.picture_medium || null,
    duration: item.duration || 0,
    preview: item.preview || null,
  }
}

export async function searchTracks(q, limit = 30) {
  const url = `https://api.deezer.com/search?q=${encodeURIComponent(q)}&order=RANKING&limit=${limit}`
  const data = await jsonp(url)
  return (data?.data || []).map(conceptTrack).filter((t) => t.preview)
}

export async function topTracks(limit = 24) {
  const url = `https://api.deezer.com/chart/0/tracks?limit=${limit}`
  const data = await jsonp(url)
  return (data?.data || []).map(conceptTrack).filter((t) => t.preview)
}

function parseLen(s) {
  if (typeof s === 'number') return s
  if (!s) return 0
  const [m, sec] = String(s).split(':').map(Number)
  return (m || 0) * 60 + (sec || 0)
}

function pickAudioFile(files) {
  const mp3s = (files || []).filter((f) => /\.mp3$/i.test(f?.name || ''))
  if (!mp3s.length) return null
  const scored = mp3s
    .map((f) => ({ f, len: parseLen(f.length) }))
    .filter((x) => x.len >= 25 && x.len <= 7200)
    .sort((a, b) => Math.abs(a.len - 200) - Math.abs(b.len - 200))
  return (scored[0] || { f: mp3s[0] }).f
}

export async function searchIATracks(q, rows = 18) {
  const query = `title:(${q}) AND mediatype:audio`
  const url = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(query)}&fl[]=identifier&fl[]=title&fl[]=creator&fl[]=downloads&fl[]=year&rows=${rows}&page=1&output=json&sort[]=downloads+desc`
  const res = await fetch(url)
  if (!res.ok) throw new Error('ia')
  const data = await res.json()
  return (data?.response?.docs || [])
    .filter((d) => d.identifier)
    .map((d) => ({
      id: `ia-${d.identifier}`,
      title: d.title || d.identifier,
      artist: d.creator || 'Internet Archive',
      album: String(d.year || ''),
      coverUrl: `https://archive.org/services/img/${encodeURIComponent(d.identifier)}`,
      duration: 0,
      preview: null,
      identifier: d.identifier,
    }))
}

const AUDIUS_API = 'https://discoveryprovider.audius.co/v1'

export async function searchAudiusTracks(q, limit = 18) {
  const url = `${AUDIUS_API}/tracks/search?query=${encodeURIComponent(q)}&limit=${limit}`
  const res = await fetch(url)
  if (!res.ok) throw new Error('au')
  const data = await res.json()
  return (data?.data || [])
    .filter((t) => t.id && t.title)
    .map((t) => ({
      id: `au-${t.id}`,
      title: t.title,
      artist: t.user?.name || 'Audius',
      album: t.genre || '',
      coverUrl: t.cover_art_sizes
        ? `https://creatornode.audius.co/content/${encodeURIComponent(t.cover_art_sizes)}/480x480.jpg`
        : '',
      duration: Number(t.duration) || 0,
      preview: null,
      audiusId: t.id,
    }))
}

export async function resolveAudiusStream(id) {
  return { url: `${AUDIUS_API}/tracks/${encodeURIComponent(id)}/stream?format=mp3`, playDuration: 0 }
}

export async function resolveIAStream(identifier) {
  const res = await fetch(`https://archive.org/metadata/${encodeURIComponent(identifier)}`)
  if (!res.ok) throw new Error('ia meta')
  const data = await res.json()
  const file = pickAudioFile(data?.files)
  if (!file) throw new Error('ia nofile')
  return {
    url: `https://archive.org/download/${identifier}/${encodeURIComponent(file.name)}`,
    playDuration: parseLen(file.length) || 0,
  }
}