globalThis.FileReader = class { readAsDataURL(b){ b.arrayBuffer().then(buf=>{ this.result=`data:${b.type};base64,${Buffer.from(buf).toString('base64')}`; this.onload&&this.onload() }) } }
const { signInEmail, getSession, pullBackup } = await import('./cloud.mjs')
function trackSignature(t){return JSON.stringify({id:t?.id||'',title:t?.title||'',artist:t?.artist||'',album:t?.album||'',duration:Math.round(t?.duration||0),fav:t?.fav===true,cover:Array.isArray(t?.cover)?t.cover:null,coverRemote:t?.coverRemote||null,addedAt:t?.addedAt||0})}
function signature({library,settings,equalizer,lyricSync}={}){return JSON.stringify({t:(library||[]).map(trackSignature).sort(),s:settings||null,e:equalizer||null,l:lyricSync||null})}
function backupSignature(b){return signature({library:b?.tracks||[],settings:b?.settings,equalizer:b?.equalizer,lyricSync:b?.lyricSync})}
await signInEmail('bot-teste-nebulatune@example.com','teste123456')
const { user } = await getSession()
const d = await pullBackup(user.id)
console.log('CLOUD SIG:', backupSignature(d))
console.log('settings cloud:', JSON.stringify(d.settings))
console.log('equalizer cloud:', JSON.stringify(d.equalizer))
